import hashlib
import sqlite3
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from database.schema import get_connection


def hash_password(password: str) -> str:
    return hashlib.sha256(password.encode()).hexdigest()


def authenticate(username: str, password: str):
    """Returns user dict if valid, else None."""
    conn = get_connection()
    row = conn.execute(
        "SELECT id, username, role FROM users WHERE username=? AND password_hash=?",
        (username, hash_password(password))
    ).fetchone()
    conn.close()
    if row:
        return {"id": row["id"], "username": row["username"], "role": row["role"]}
    return None


def register_intern(username: str, password: str, full_name: str, email: str, department: str,
                    start_date: str, end_date: str, mentor: str = "", phone: str = ""):
    """Register a new intern. Returns (success, message)."""
    conn = get_connection()
    try:
        conn.execute("INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
                     (username, hash_password(password), "intern"))
        uid = conn.execute("SELECT id FROM users WHERE username=?", (username,)).fetchone()[0]
        conn.execute("""
            INSERT INTO intern_profiles (user_id, full_name, email, phone, department, mentor, start_date, end_date)
            VALUES (?,?,?,?,?,?,?,?)
        """, (uid, full_name, email, phone, department, mentor, start_date, end_date))
        conn.commit()
        return True, "Registered successfully!"
    except sqlite3.IntegrityError:
        return False, "Username already exists."
    finally:
        conn.close()


def change_password(user_id: int, old_password: str, new_password: str):
    conn = get_connection()
    row = conn.execute("SELECT password_hash FROM users WHERE id=?", (user_id,)).fetchone()
    if row and row["password_hash"] == hash_password(old_password):
        conn.execute("UPDATE users SET password_hash=? WHERE id=?",
                     (hash_password(new_password), user_id))
        conn.commit()
        conn.close()
        return True, "Password changed."
    conn.close()
    return False, "Incorrect current password."
