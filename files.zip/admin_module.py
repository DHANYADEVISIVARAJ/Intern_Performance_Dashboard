import streamlit as st
from datetime import datetime
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.data_ops import (
    get_all_interns, get_intern_full_report, get_all_attendance_today,
    get_attendance_summary, get_task_summary, get_evaluations,
    add_evaluation, get_announcements, add_announcement, add_suggestion,
    mark_attendance
)
from analytics.engine import compute_kpis, get_admin_overview, get_evaluation_trend, \
    get_attendance_trend, get_task_progress_over_time
from analytics.charts import (
    attendance_pie, evaluation_radar, evaluation_trend_line, skill_bar_chart,
    task_status_bar, overall_gauge, department_bar, top_performers_chart, attendance_trend_chart
)


def badge(text, kind="info"):
    return f'<span class="badge badge-{kind}">{text}</span>'


def kpi_card(icon, value, label, sub="", color="primary"):
    return f"""
    <div class="kpi-card {color}">
        <div class="kpi-icon">{icon}</div>
        <div class="kpi-value">{value}</div>
        <div class="kpi-label">{label}</div>
        {"<div class='kpi-sub'>" + sub + "</div>" if sub else ""}
    </div>"""


def progress_bar(pct):
    return f"""<div class="progress-wrap"><div class="progress-fill" style="width:{pct}%"></div></div>"""


def render_admin_dashboard(user):
    uid = user["id"]

    with st.sidebar:
        st.markdown("### Admin Navigation")
        pages = {
            "🏠 Overview": "overview",
            "👥 All Interns": "interns",
            "📅 Attendance Today": "attendance",
            "📊 Analytics": "analytics",
            "📝 Evaluations": "evaluations",
            "📢 Announcements": "announcements",
            "💡 Send Suggestions": "suggestions_admin",
        }
        if "admin_page" not in st.session_state:
            st.session_state.admin_page = "overview"
        if "selected_intern" not in st.session_state:
            st.session_state.selected_intern = None

        for label, key in pages.items():
            active = st.session_state.admin_page == key
            if st.button(label, key=f"admin_nav_{key}", use_container_width=True,
                         type="primary" if active else "secondary"):
                st.session_state.admin_page = key
                st.session_state.selected_intern = None
                st.rerun()

    page = st.session_state.admin_page

    # If viewing individual intern detail
    if st.session_state.selected_intern:
        render_intern_detail(st.session_state.selected_intern, uid)
        return

    # ── OVERVIEW ─────────────────────────────────────────────────────────
    if page == "overview":
        overview = get_admin_overview()
        st.markdown(f"""
        <div class="page-header">
            <div>
                <div class="page-header-title">🏠 Admin Overview</div>
                <div class="page-header-sub">Company Intern Analytics · {datetime.now().strftime("%A, %d %B %Y")}</div>
            </div>
            <div style="font-size:2.5rem">📊</div>
        </div>""", unsafe_allow_html=True)

        att_today = overview["attendance_today"]
        total = overview["total_interns"]
        present = att_today.get("present", 0)
        absent = att_today.get("absent", 0)
        late = att_today.get("late", 0)

        c1, c2, c3, c4, c5 = st.columns(5)
        with c1:
            st.markdown(kpi_card("👥", total, "Total Interns", color="primary"), unsafe_allow_html=True)
        with c2:
            st.markdown(kpi_card("✅", present, "Present Today", color="success"), unsafe_allow_html=True)
        with c3:
            st.markdown(kpi_card("❌", absent, "Absent Today", color="danger"), unsafe_allow_html=True)
        with c4:
            st.markdown(kpi_card("⏰", late, "Late Today", color="warning"), unsafe_allow_html=True)
        with c5:
            tasks = overview["task_stats"]
            done_tasks = tasks.get("done", 0)
            st.markdown(kpi_card("📋", done_tasks, "Tasks Done", color="info"), unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)
        col1, col2 = st.columns(2)
        with col1:
            st.plotly_chart(department_bar(overview["departments"]), use_container_width=True)
        with col2:
            st.plotly_chart(top_performers_chart(overview["top_performers"]), use_container_width=True)

        col1, col2 = st.columns(2)
        with col1:
            if att_today:
                st.plotly_chart(attendance_pie(att_today), use_container_width=True)
        with col2:
            if overview["task_stats"]:
                st.plotly_chart(task_status_bar(overview["task_stats"]), use_container_width=True)

    # ── ALL INTERNS ───────────────────────────────────────────────────────
    elif page == "interns":
        st.markdown('<div class="page-header"><div><div class="page-header-title">👥 All Interns</div><div class="page-header-sub">Click on an intern to view full profile and analytics</div></div></div>', unsafe_allow_html=True)

        interns = get_all_interns()
        search = st.text_input("🔍 Search by name, department...", placeholder="Type to filter...")
        dept_filter = st.selectbox("Filter by Department", ["All"] + list(set(i["department"] for i in interns)))

        filtered = interns
        if search:
            filtered = [i for i in filtered if search.lower() in i["full_name"].lower()
                        or search.lower() in (i.get("department") or "").lower()]
        if dept_filter != "All":
            filtered = [i for i in filtered if i.get("department") == dept_filter]

        st.markdown(f"**{len(filtered)} interns found**")

        for intern in filtered:
            iuid = intern["user_id"]
            kpis = compute_kpis(iuid)
            att_sum = get_attendance_summary(iuid)
            task_sum = get_task_summary(iuid)
            done = task_sum.get("done", 0)
            total_tasks = sum(task_sum.values())
            score_color = "success" if kpis["latest_eval_score"] >= 7 else "warning" if kpis["latest_eval_score"] >= 5 else "danger"

            col1, col2 = st.columns([3, 1])
            with col1:
                st.markdown(f"""
                <div class="intern-row">
                    <div class="sidebar-avatar">{intern['full_name'][0]}</div>
                    <div style="flex:1">
                        <div style="font-weight:700;font-size:1rem">{intern['full_name']}</div>
                        <div style="font-size:0.8rem;color:#94a3b8">@{intern['username']} · {intern.get('department','N/A')} · Mentor: {intern.get('mentor','—')}</div>
                        <div style="margin-top:6px;display:flex;gap:8px">
                            {badge(f"Attendance: {att_sum['attendance_rate']}%", 'success' if att_sum['attendance_rate']>=80 else 'warning')}
                            {badge(f"Tasks: {done}/{total_tasks}", 'info')}
                            {badge(f"Score: {kpis['latest_eval_score']}/10", score_color)}
                            {badge(intern.get('department',''), 'purple')}
                        </div>
                    </div>
                </div>""", unsafe_allow_html=True)
            with col2:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("View Details →", key=f"view_{iuid}", use_container_width=True):
                    st.session_state.selected_intern = iuid
                    st.rerun()

    # ── ATTENDANCE TODAY ──────────────────────────────────────────────────
    elif page == "attendance":
        st.markdown('<div class="page-header"><div><div class="page-header-title">📅 Attendance Tracking</div><div class="page-header-sub">Real-time attendance overview for today</div></div></div>', unsafe_allow_html=True)

        today_records = get_all_attendance_today()
        st.markdown(f'<div class="section-title">📋 Today\'s Attendance — {datetime.now().strftime("%d %B %Y")}</div>', unsafe_allow_html=True)

        status_color = {"present": "success", "absent": "danger", "late": "warning",
                        "half_day": "info", None: "purple"}

        # Mark attendance for intern
        with st.expander("✏️ Mark/Update Attendance for an Intern"):
            interns = get_all_interns()
            intern_options = {i["full_name"]: i["user_id"] for i in interns}
            selected_name = st.selectbox("Select Intern", list(intern_options.keys()))
            col1, col2, col3 = st.columns(3)
            with col1:
                mark_status = st.selectbox("Status", ["present", "absent", "late", "half_day"])
            with col2:
                mark_date = st.date_input("Date", value=datetime.now().date())
            with col3:
                st.markdown("<br>", unsafe_allow_html=True)
                if st.button("Mark Attendance"):
                    mark_attendance(intern_options[selected_name], str(mark_date), mark_status)
                    st.success("Marked!")
                    st.rerun()

        for record in today_records:
            status = record.get("status")
            bk = status_color.get(status, "purple")
            st.markdown(f"""
            <div class="task-item">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div style="display:flex;align-items:center;gap:12px">
                        <div class="sidebar-avatar">{(record.get('full_name') or 'U')[0]}</div>
                        <div>
                            <div class="task-title">{record.get('full_name','Unknown')}</div>
                            <div class="task-meta">{record.get('department','N/A')} · Check-in: {record.get('check_in','—')} · Check-out: {record.get('check_out','—')}</div>
                        </div>
                    </div>
                    {badge(status.replace('_',' ').title() if status else 'Not Marked', bk)}
                </div>
            </div>""", unsafe_allow_html=True)

    # ── ANALYTICS ─────────────────────────────────────────────────────────
    elif page == "analytics":
        st.markdown('<div class="page-header"><div><div class="page-header-title">📊 Department Analytics</div><div class="page-header-sub">Compare performance across interns and departments</div></div></div>', unsafe_allow_html=True)

        interns = get_all_interns()
        selected_name = st.selectbox("Select Intern to Analyze",
                                      {i["full_name"]: i["user_id"] for i in interns}.keys())
        iuid = {i["full_name"]: i["user_id"] for i in interns}[selected_name]

        kpis = compute_kpis(iuid)
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.metric("Overall Score", f"{kpis['overall_performance']}%")
        with c2:
            st.metric("Attendance Rate", f"{kpis['attendance_rate']}%")
        with c3:
            st.metric("Task Completion", f"{kpis['task_completion_rate']}%")
        with c4:
            st.metric("Eval Score", f"{kpis['latest_eval_score']}/10")

        col1, col2 = st.columns(2)
        with col1:
            trend = get_attendance_trend(iuid)
            st.plotly_chart(attendance_trend_chart(trend), use_container_width=True)
        with col2:
            eval_df = get_evaluation_trend(iuid)
            st.plotly_chart(evaluation_trend_line(eval_df), use_container_width=True)

        col1, col2 = st.columns(2)
        with col1:
            evals = get_evaluations(iuid)
            if evals:
                st.plotly_chart(evaluation_radar(evals[0]), use_container_width=True)
        with col2:
            task_sum = get_task_summary(iuid)
            st.plotly_chart(task_status_bar(task_sum), use_container_width=True)

    # ── EVALUATIONS ───────────────────────────────────────────────────────
    elif page == "evaluations":
        st.markdown('<div class="page-header"><div><div class="page-header-title">📝 Conduct Evaluation</div><div class="page-header-sub">Rate intern performance across key dimensions</div></div></div>', unsafe_allow_html=True)

        interns = get_all_interns()
        intern_map = {i["full_name"]: i["user_id"] for i in interns}
        selected_name = st.selectbox("Select Intern", list(intern_map.keys()))
        iuid = intern_map[selected_name]

        with st.form("eval_form"):
            st.markdown("#### 🎯 Rate each dimension (1-10)")
            col1, col2, col3 = st.columns(3)
            with col1:
                comm = st.slider("Communication", 1, 10, 7)
                tech = st.slider("Technical Skills", 1, 10, 7)
            with col2:
                team = st.slider("Teamwork", 1, 10, 7)
                init = st.slider("Initiative", 1, 10, 7)
            with col3:
                punct = st.slider("Punctuality", 1, 10, 7)
                qual = st.slider("Quality of Work", 1, 10, 7)

            overall = (comm + tech + team + init + punct + qual) / 6
            st.metric("Computed Overall Score", f"{overall:.2f}/10")
            eval_date = st.date_input("Evaluation Date", value=datetime.now().date())
            feedback = st.text_area("Feedback / Comments", height=100)

            if st.form_submit_button("✅ Submit Evaluation", use_container_width=True):
                add_evaluation(iuid, uid, str(eval_date),
                               {"communication": comm, "technical_skills": tech,
                                "teamwork": team, "initiative": init,
                                "punctuality": punct, "quality_of_work": qual}, feedback)
                st.success(f"✅ Evaluation submitted for {selected_name}!")

        # History
        st.markdown('<div class="section-title">📋 Past Evaluations</div>', unsafe_allow_html=True)
        past = get_evaluations(iuid)
        for e in past:
            st.markdown(f"""
            <div class="announcement-card">
                <div style="display:flex;justify-content:space-between">
                    <b>📅 {e['eval_date']}</b>
                    <span style="color:#10b981;font-weight:700">{e['overall_score']}/10</span>
                </div>
                <div style="font-size:0.82rem;color:#94a3b8;margin-top:4px">
                    Comm: {e.get('communication')} · Tech: {e.get('technical_skills')} · Team: {e.get('teamwork')} · 
                    Init: {e.get('initiative')} · Punct: {e.get('punctuality')} · Quality: {e.get('quality_of_work')}
                </div>
                {"<div style='margin-top:6px;font-size:0.82rem'>💬 " + e['feedback'] + "</div>" if e.get('feedback') else ""}
            </div>""", unsafe_allow_html=True)

    # ── ANNOUNCEMENTS ─────────────────────────────────────────────────────
    elif page == "announcements":
        st.markdown('<div class="page-header"><div><div class="page-header-title">📢 Announcements</div><div class="page-header-sub">Post updates and notices to all interns</div></div></div>', unsafe_allow_html=True)

        with st.form("ann_form"):
            title = st.text_input("Title*")
            content = st.text_area("Message*", height=100)
            if st.form_submit_button("📢 Post Announcement", use_container_width=True):
                if title and content:
                    add_announcement(uid, title, content)
                    st.success("✅ Announcement posted!")
                    st.rerun()

        st.markdown('<div class="section-title">📋 All Announcements</div>', unsafe_allow_html=True)
        for ann in get_announcements():
            st.markdown(f"""
            <div class="announcement-card">
                <div style="display:flex;justify-content:space-between">
                    <div class="announcement-title">📌 {ann['title']}</div>
                    <div class="announcement-date">{ann['created_at'][:10]}</div>
                </div>
                <div style="margin-top:8px;color:#cbd5e1">{ann['content']}</div>
            </div>""", unsafe_allow_html=True)

    # ── SUGGESTIONS ───────────────────────────────────────────────────────
    elif page == "suggestions_admin":
        st.markdown('<div class="page-header"><div><div class="page-header-title">💡 Send Suggestions</div><div class="page-header-sub">Send personalized feedback and advice to interns</div></div></div>', unsafe_allow_html=True)

        interns = get_all_interns()
        intern_map = {i["full_name"]: i["user_id"] for i in interns}
        selected_name = st.selectbox("Select Intern", list(intern_map.keys()))
        iuid = intern_map[selected_name]

        with st.form("sugg_form"):
            sugg_text = st.text_area("Suggestion / Feedback*", height=120)
            sugg_cat = st.selectbox("Category", ["Technical", "Soft Skills", "Career", "Learning",
                                                   "Attendance", "Positive", "General"])
            if st.form_submit_button("💌 Send Suggestion", use_container_width=True):
                if sugg_text:
                    add_suggestion(iuid, sugg_text, sugg_cat)
                    st.success(f"✅ Suggestion sent to {selected_name}!")

        # Quick AI KPI summary
        kpis = compute_kpis(iuid)
        st.markdown('<div class="section-title">📊 Performance Quick View</div>', unsafe_allow_html=True)
        c1, c2, c3, c4 = st.columns(4)
        with c1:
            st.metric("Attendance", f"{kpis['attendance_rate']}%")
        with c2:
            st.metric("Tasks Done", f"{kpis['task_completion_rate']}%")
        with c3:
            st.metric("Eval Score", f"{kpis['latest_eval_score']}/10")
        with c4:
            st.metric("Overall", f"{kpis['overall_performance']}%")


# ─── INTERN DETAIL VIEW ───────────────────────────────────────────────────────

def render_intern_detail(iuid: int, admin_uid: int):
    from backend.data_ops import get_profile, get_skills
    if st.button("← Back to Interns List", type="secondary"):
        st.session_state.selected_intern = None
        st.session_state.admin_page = "interns"
        st.rerun()

    report = get_intern_full_report(iuid)
    profile = report["profile"] or {}
    kpis = compute_kpis(iuid)

    st.markdown(f"""
    <div class="page-header">
        <div style="display:flex;align-items:center;gap:16px">
            <div class="sidebar-avatar" style="width:56px;height:56px;font-size:1.5rem">{(profile.get('full_name') or 'U')[0]}</div>
            <div>
                <div class="page-header-title">{profile.get('full_name','Unknown')}</div>
                <div class="page-header-sub">
                    @{profile.get('username','N/A')} &nbsp;·&nbsp;
                    {profile.get('department','N/A')} &nbsp;·&nbsp;
                    Mentor: {profile.get('mentor','—')} &nbsp;·&nbsp;
                    {profile.get('start_date','')} → {profile.get('end_date','')}
                </div>
            </div>
        </div>
    </div>""", unsafe_allow_html=True)

    # KPIs
    c1, c2, c3, c4, c5 = st.columns(5)
    with c1:
        st.markdown(kpi_card("📈", f"{kpis['overall_performance']}%", "Overall", color="primary"), unsafe_allow_html=True)
    with c2:
        st.markdown(kpi_card("📅", f"{kpis['attendance_rate']}%", "Attendance", color="success" if kpis['attendance_rate']>=80 else "warning"), unsafe_allow_html=True)
    with c3:
        st.markdown(kpi_card("✅", f"{kpis['task_completion_rate']}%", "Tasks Done", color="info"), unsafe_allow_html=True)
    with c4:
        st.markdown(kpi_card("⭐", f"{kpis['latest_eval_score']}/10", "Eval Score", color="success" if kpis['latest_eval_score']>=7 else "warning"), unsafe_allow_html=True)
    with c5:
        st.markdown(kpi_card("🎯", f"{kpis['avg_skill_level']}/10", "Skill Avg", color="purple"), unsafe_allow_html=True)

    tab1, tab2, tab3, tab4, tab5 = st.tabs(["📊 Overview", "📅 Attendance", "✅ Tasks", "📝 Evaluations", "🎯 Skills"])

    with tab1:
        col1, col2 = st.columns(2)
        with col1:
            st.plotly_chart(overall_gauge(kpis["overall_performance"]), use_container_width=True)
        with col2:
            evals = report["evaluations"]
            if evals:
                st.plotly_chart(evaluation_radar(evals[0]), use_container_width=True)

        # Profile info
        st.markdown('<div class="section-title">👤 Profile Info</div>', unsafe_allow_html=True)
        cols = st.columns(2)
        info_items = [
            ("Email", profile.get("email")), ("Phone", profile.get("phone")),
            ("Skills", profile.get("skills")), ("Bio", profile.get("bio")),
            ("GitHub", profile.get("github_url")), ("LinkedIn", profile.get("linkedin_url")),
        ]
        for i, (label, val) in enumerate(info_items):
            with cols[i % 2]:
                if val:
                    st.markdown(f"**{label}:** {val}")

    with tab2:
        col1, col2 = st.columns(2)
        with col1:
            att_sum = report["attendance_summary"]
            st.plotly_chart(attendance_pie(att_sum["summary"]), use_container_width=True)
        with col2:
            trend = get_attendance_trend(iuid)
            st.plotly_chart(attendance_trend_chart(trend), use_container_width=True)

        st.markdown('<div class="section-title">🗓️ Recent Attendance</div>', unsafe_allow_html=True)
        status_badge = {"present": "success", "absent": "danger", "late": "warning", "half_day": "info"}
        for r in report["attendance"][:15]:
            st.markdown(f"""
            <div class="task-item">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div class="task-title">📆 {r['date']}</div>
                        <div class="task-meta">In: {r.get('check_in','—')} · Out: {r.get('check_out','—')}</div>
                    </div>
                    {badge(r['status'].replace('_',' ').title(), status_badge.get(r['status'],'info'))}
                </div>
            </div>""", unsafe_allow_html=True)

    with tab3:
        task_sum = report["task_summary"]
        st.plotly_chart(task_status_bar(task_sum), use_container_width=True)
        tasks = report["tasks"]
        status_colors = {"todo": "info", "in_progress": "warning", "review": "purple", "done": "success"}
        for t in tasks:
            st.markdown(f"""
            <div class="task-item">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div class="task-title">📌 {t['title']}</div>
                        <div class="task-meta">{t['category']} · Due: {t.get('due_date','—')} · Priority: {t.get('priority','—')}</div>
                        <div class="progress-wrap" style="width:200px;margin-top:6px">
                            <div class="progress-fill" style="width:{t['progress']}%"></div>
                        </div>
                        <div style="font-size:0.75rem;color:#64748b">{t['progress']}% complete</div>
                    </div>
                    {badge(t['status'].replace('_',' ').title(), status_colors.get(t['status'],'info'))}
                </div>
            </div>""", unsafe_allow_html=True)

    with tab4:
        evals = report["evaluations"]
        if not evals:
            st.info("No evaluations found.")
        else:
            col1, col2 = st.columns(2)
            with col1:
                st.plotly_chart(evaluation_radar(evals[0]), use_container_width=True)
            with col2:
                eval_df = get_evaluation_trend(iuid)
                st.plotly_chart(evaluation_trend_line(eval_df), use_container_width=True)

            for e in evals:
                st.markdown(f"""
                <div class="announcement-card">
                    <div style="display:flex;justify-content:space-between">
                        <b>📅 {e['eval_date']}</b>
                        <span style="color:#10b981;font-weight:700">{e['overall_score']}/10</span>
                    </div>
                    <div style="font-size:0.82rem;color:#94a3b8;margin-top:4px">
                        Comm: {e.get('communication')} · Tech: {e.get('technical_skills')} · 
                        Team: {e.get('teamwork')} · Init: {e.get('initiative')} · 
                        Punct: {e.get('punctuality')} · Quality: {e.get('quality_of_work')}
                    </div>
                    {"<div style='margin-top:6px;font-size:0.82rem'>💬 " + e['feedback'] + "</div>" if e.get('feedback') else ""}
                </div>""", unsafe_allow_html=True)

        # Add evaluation
        st.markdown('<div class="section-title">➕ Add New Evaluation</div>', unsafe_allow_html=True)
        with st.form(f"eval_detail_{iuid}"):
            col1, col2, col3 = st.columns(3)
            with col1:
                comm = st.slider("Communication", 1, 10, 7, key=f"c1_{iuid}")
                tech = st.slider("Technical", 1, 10, 7, key=f"c2_{iuid}")
            with col2:
                team = st.slider("Teamwork", 1, 10, 7, key=f"c3_{iuid}")
                init = st.slider("Initiative", 1, 10, 7, key=f"c4_{iuid}")
            with col3:
                punct = st.slider("Punctuality", 1, 10, 7, key=f"c5_{iuid}")
                qual = st.slider("Quality", 1, 10, 7, key=f"c6_{iuid}")
            feedback = st.text_area("Feedback", key=f"fb_{iuid}")
            edate = st.date_input("Date", key=f"ed_{iuid}")
            if st.form_submit_button("Submit Evaluation", use_container_width=True):
                from backend.data_ops import add_evaluation
                add_evaluation(iuid, admin_uid, str(edate),
                               {"communication": comm, "technical_skills": tech, "teamwork": team,
                                "initiative": init, "punctuality": punct, "quality_of_work": qual}, feedback)
                st.success("Evaluation added!")
                st.rerun()

    with tab5:
        skills = report["skills"]
        st.plotly_chart(skill_bar_chart(skills), use_container_width=True)
        for s in sorted(skills, key=lambda x: -x["proficiency"]):
            lc = "success" if s["proficiency"] >= 7 else "warning" if s["proficiency"] >= 4 else "danger"
            st.markdown(f"""
            <div class="task-item">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div class="task-title">🔷 {s['skill_name']}</div>
                    {badge(f"{s['proficiency']}/10", lc)}
                </div>
                <div class="progress-wrap">
                    <div class="progress-fill" style="width:{s['proficiency']*10}%"></div>
                </div>
            </div>""", unsafe_allow_html=True)
