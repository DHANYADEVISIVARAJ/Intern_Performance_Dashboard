import streamlit as st
from datetime import datetime, date
import sys, os
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from backend.data_ops import (
    get_profile, update_profile, get_attendance, mark_attendance,
    get_attendance_summary, get_tasks, add_task, update_task, delete_task,
    get_task_summary, get_evaluations, get_skills, upsert_skill,
    get_announcements, get_suggestions, add_suggestion
)
from analytics.engine import compute_kpis, get_attendance_trend, get_task_progress_over_time, \
    get_evaluation_trend, generate_suggestions
from analytics.charts import (
    attendance_pie, attendance_trend_chart, task_status_bar,
    evaluation_radar, evaluation_trend_line, skill_bar_chart, overall_gauge
)


def kpi_card(icon, value, label, sub="", color="primary"):
    return f"""
    <div class="kpi-card {color}">
        <div class="kpi-icon">{icon}</div>
        <div class="kpi-value">{value}</div>
        <div class="kpi-label">{label}</div>
        {"<div class='kpi-sub'>" + sub + "</div>" if sub else ""}
    </div>"""


def badge(text, kind="info"):
    return f'<span class="badge badge-{kind}">{text}</span>'


def progress_bar(pct, color="var(--primary)"):
    return f"""
    <div class="progress-wrap">
        <div class="progress-fill" style="width:{pct}%; background:{color};"></div>
    </div>"""


def render_intern_dashboard(user):
    uid = user["id"]

    # ── SIDEBAR NAV ──────────────────────────────────────────────────────
    with st.sidebar:
        st.markdown("### Navigation")
        pages = {
            "🏠 Dashboard": "home",
            "👤 My Profile": "profile",
            "📅 Attendance": "attendance",
            "✅ My Tasks": "tasks",
            "📊 Evaluations": "evaluations",
            "🎯 Skills": "skills",
            "💡 Suggestions": "suggestions",
            "📢 Announcements": "announcements",
        }
        if "intern_page" not in st.session_state:
            st.session_state.intern_page = "home"

        for label, key in pages.items():
            active = "primary" if st.session_state.intern_page == key else "secondary"
            if st.button(label, key=f"nav_{key}", use_container_width=True,
                         type="primary" if active == "primary" else "secondary"):
                st.session_state.intern_page = key
                st.rerun()

    page = st.session_state.intern_page

    # ── HOME / OVERVIEW ──────────────────────────────────────────────────
    if page == "home":
        profile = get_profile(uid)
        name = profile["full_name"] if profile else user["username"]
        dept = profile["department"] if profile else "N/A"

        st.markdown(f"""
        <div class="page-header">
            <div>
                <div class="page-header-title">👋 Welcome back, {name.split()[0]}!</div>
                <div class="page-header-sub">📌 {dept} &nbsp;|&nbsp; {datetime.now().strftime("%A, %d %B %Y")}</div>
            </div>
            <div style="font-size:2.5rem">🎯</div>
        </div>""", unsafe_allow_html=True)

        kpis = compute_kpis(uid)

        # KPI row
        c1, c2, c3, c4, c5 = st.columns(5)
        with c1:
            st.markdown(kpi_card("📈", f"{kpis['overall_performance']}%", "Overall Score", color="primary"), unsafe_allow_html=True)
        with c2:
            st.markdown(kpi_card("📅", f"{kpis['attendance_rate']}%", "Attendance Rate",
                                  "Last 30 days", "success" if kpis['attendance_rate'] >= 80 else "warning"), unsafe_allow_html=True)
        with c3:
            st.markdown(kpi_card("✅", f"{kpis['task_completion_rate']}%", "Tasks Completed",
                                  f"{kpis['completed_tasks']}/{kpis['total_tasks']}", "info"), unsafe_allow_html=True)
        with c4:
            st.markdown(kpi_card("⭐", f"{kpis['latest_eval_score']}/10", "Last Eval Score",
                                  color="success" if kpis['latest_eval_score'] >= 7 else "warning"), unsafe_allow_html=True)
        with c5:
            st.markdown(kpi_card("🎯", f"{kpis['avg_skill_level']}/10", "Avg Skill Level", color="purple"), unsafe_allow_html=True)

        st.markdown("<br>", unsafe_allow_html=True)

        # Charts row
        col1, col2, col3 = st.columns([1.2, 1, 1])
        with col1:
            att_trend = get_attendance_trend(uid)
            st.plotly_chart(attendance_trend_chart(att_trend), use_container_width=True)
        with col2:
            att_summary = get_attendance_summary(uid)["summary"]
            if att_summary:
                st.plotly_chart(attendance_pie(att_summary), use_container_width=True)
        with col3:
            task_summary = get_task_summary(uid)
            st.plotly_chart(task_status_bar(task_summary), use_container_width=True)

        # Gauge + latest eval radar
        col1, col2 = st.columns(2)
        with col1:
            st.plotly_chart(overall_gauge(kpis["overall_performance"]), use_container_width=True)
        with col2:
            evals = get_evaluations(uid)
            if evals:
                st.plotly_chart(evaluation_radar(evals[0]), use_container_width=True)

        # Quick suggestions
        st.markdown('<div class="section-title">💡 AI Suggestions for You</div>', unsafe_allow_html=True)
        sugg = generate_suggestions(uid)
        for s in sugg[:3]:
            st.markdown(f'<div class="suggestion-card {s["priority"]}">{s["text"]}</div>',
                        unsafe_allow_html=True)

        # Recent announcements
        st.markdown('<div class="section-title">📢 Latest Announcements</div>', unsafe_allow_html=True)
        for ann in get_announcements()[:2]:
            st.markdown(f"""
            <div class="announcement-card">
                <div class="announcement-title">📌 {ann['title']}</div>
                <div class="announcement-date">{ann['created_at'][:10]}</div>
                <div style="margin-top:6px;font-size:0.85rem;color:#94a3b8">{ann['content']}</div>
            </div>""", unsafe_allow_html=True)

    # ── PROFILE ──────────────────────────────────────────────────────────
    elif page == "profile":
        profile = get_profile(uid) or {}
        st.markdown('<div class="page-header"><div><div class="page-header-title">👤 My Profile</div><div class="page-header-sub">Update your information and preferences</div></div></div>', unsafe_allow_html=True)

        with st.form("profile_form"):
            col1, col2 = st.columns(2)
            with col1:
                full_name = st.text_input("Full Name*", value=profile.get("full_name", ""))
                email = st.text_input("Email*", value=profile.get("email", ""))
                phone = st.text_input("Phone", value=profile.get("phone", ""))
                department = st.selectbox("Department",
                    ["Data Science", "Analytics", "Engineering", "Design", "Marketing", "Operations"],
                    index=["Data Science", "Analytics", "Engineering", "Design", "Marketing", "Operations"].index(profile.get("department", "Data Science")))
            with col2:
                mentor = st.text_input("Mentor", value=profile.get("mentor", ""))
                github_url = st.text_input("GitHub URL", value=profile.get("github_url", "") or "")
                linkedin_url = st.text_input("LinkedIn URL", value=profile.get("linkedin_url", "") or "")
                skills = st.text_input("Skills (comma-separated)", value=profile.get("skills", "") or "")

            bio = st.text_area("Bio / About Me", value=profile.get("bio", "") or "", height=100)
            col3, col4 = st.columns(2)
            with col3:
                start_date = st.text_input("Start Date (YYYY-MM-DD)", value=profile.get("start_date", ""))
            with col4:
                end_date = st.text_input("End Date (YYYY-MM-DD)", value=profile.get("end_date", ""))

            if st.form_submit_button("💾 Save Profile", use_container_width=True):
                update_profile(uid, {
                    "full_name": full_name, "email": email, "phone": phone,
                    "department": department, "mentor": mentor, "github_url": github_url,
                    "linkedin_url": linkedin_url, "skills": skills, "bio": bio,
                    "start_date": start_date, "end_date": end_date
                })
                st.success("✅ Profile updated successfully!")

        # Change password section
        st.markdown('<div class="section-title">🔐 Change Password</div>', unsafe_allow_html=True)
        with st.form("pw_form"):
            old_pw = st.text_input("Current Password", type="password")
            new_pw = st.text_input("New Password", type="password")
            confirm_pw = st.text_input("Confirm New Password", type="password")
            if st.form_submit_button("🔒 Update Password"):
                from backend.auth import change_password
                if new_pw != confirm_pw:
                    st.error("Passwords do not match.")
                else:
                    ok, msg = change_password(uid, old_pw, new_pw)
                    st.success(msg) if ok else st.error(msg)

    # ── ATTENDANCE ────────────────────────────────────────────────────────
    elif page == "attendance":
        st.markdown('<div class="page-header"><div><div class="page-header-title">📅 Attendance</div><div class="page-header-sub">Track your daily check-ins and patterns</div></div></div>', unsafe_allow_html=True)

        # Mark today
        st.markdown('<div class="section-title">✏️ Mark Today\'s Attendance</div>', unsafe_allow_html=True)
        col1, col2, col3, col4 = st.columns(4)
        with col1:
            today_status = st.selectbox("Status", ["present", "absent", "late", "half_day"])
        with col2:
            check_in = st.text_input("Check-in time", placeholder="9:00 AM")
        with col3:
            check_out = st.text_input("Check-out time", placeholder="6:00 PM")
        with col4:
            st.markdown("<br>", unsafe_allow_html=True)
            if st.button("✅ Submit", use_container_width=True):
                mark_attendance(uid, datetime.now().strftime("%Y-%m-%d"),
                                today_status, check_in, check_out)
                st.success("Attendance marked!")
                st.rerun()

        # Charts
        col1, col2 = st.columns(2)
        with col1:
            att_sum = get_attendance_summary(uid)
            st.plotly_chart(attendance_pie(att_sum["summary"]), use_container_width=True)
        with col2:
            trend = get_attendance_trend(uid)
            st.plotly_chart(attendance_trend_chart(trend), use_container_width=True)

        # Summary stats
        col1, col2, col3, col4 = st.columns(4)
        summary = att_sum["summary"]
        with col1:
            st.metric("Present Days", summary.get("present", 0))
        with col2:
            st.metric("Absent Days", summary.get("absent", 0))
        with col3:
            st.metric("Late Arrivals", summary.get("late", 0))
        with col4:
            st.metric("Attendance Rate", f"{att_sum['attendance_rate']}%")

        # Recent attendance log
        st.markdown('<div class="section-title">🗓️ Recent Attendance Log</div>', unsafe_allow_html=True)
        records = get_attendance(uid, 20)
        status_badge = {"present": "success", "absent": "danger", "late": "warning", "half_day": "info"}
        for r in records:
            st.markdown(f"""
            <div class="task-item">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div class="task-title">📆 {r['date']}</div>
                        <div class="task-meta">Check-in: {r.get('check_in','—')} &nbsp;|&nbsp; Check-out: {r.get('check_out','—')}</div>
                    </div>
                    {badge(r['status'].replace('_',' ').title(), status_badge.get(r['status'],'info'))}
                </div>
            </div>""", unsafe_allow_html=True)

    # ── TASKS ─────────────────────────────────────────────────────────────
    elif page == "tasks":
        st.markdown('<div class="page-header"><div><div class="page-header-title">✅ My Tasks</div><div class="page-header-sub">Track assignments, projects and progress</div></div></div>', unsafe_allow_html=True)

        # Add task
        with st.expander("➕ Add New Task"):
            with st.form("add_task_form"):
                col1, col2 = st.columns(2)
                with col1:
                    title = st.text_input("Task Title*")
                    category = st.selectbox("Category", ["Data Science", "ML", "Analytics", "Backend", "Frontend", "Research", "Management"])
                with col2:
                    priority = st.selectbox("Priority", ["low", "medium", "high"])
                    due_date = st.date_input("Due Date")
                description = st.text_area("Description", height=80)
                if st.form_submit_button("Add Task", use_container_width=True):
                    if title:
                        add_task(uid, title, description, category, priority, str(due_date))
                        st.success("Task added!")
                        st.rerun()

        # Task stats
        task_sum = get_task_summary(uid)
        st.plotly_chart(task_status_bar(task_sum), use_container_width=True)

        tasks = get_tasks(uid)
        status_color = {"todo": "info", "in_progress": "warning", "review": "purple", "done": "success"}
        priority_color = {"low": "success", "medium": "warning", "high": "danger"}

        filter_status = st.selectbox("Filter by Status", ["all", "todo", "in_progress", "review", "done"])
        if filter_status != "all":
            tasks = [t for t in tasks if t["status"] == filter_status]

        for task in tasks:
            with st.expander(f"{'✅' if task['status']=='done' else '📌'} {task['title']} — {badge(task['status'].replace('_',' ').title(), status_color.get(task['status'],'info'))}", expanded=False):
                col1, col2 = st.columns([2, 1])
                with col1:
                    st.markdown(f"**📂 Category:** {task['category']}  ")
                    st.markdown(f"**📋 Description:** {task['description'] or 'N/A'}  ")
                    st.markdown(f"**📅 Due:** {task['due_date']}  ")
                    st.markdown(f"**⚡ Priority:** {badge(task['priority'], priority_color.get(task['priority'],'info'))}", unsafe_allow_html=True)
                with col2:
                    new_status = st.selectbox("Update Status", ["todo", "in_progress", "review", "done"],
                                              index=["todo", "in_progress", "review", "done"].index(task["status"]),
                                              key=f"status_{task['id']}")
                    new_progress = st.slider("Progress %", 0, 100, task["progress"], key=f"prog_{task['id']}")
                    col3, col4 = st.columns(2)
                    with col3:
                        if st.button("Save", key=f"save_{task['id']}", use_container_width=True):
                            update_task(task["id"], new_status, new_progress)
                            st.success("Updated!")
                            st.rerun()
                    with col4:
                        if st.button("🗑️ Del", key=f"del_{task['id']}", use_container_width=True):
                            delete_task(task["id"])
                            st.rerun()

                st.markdown(progress_bar(task["progress"]), unsafe_allow_html=True)
                st.caption(f"Progress: {task['progress']}%")

    # ── EVALUATIONS ───────────────────────────────────────────────────────
    elif page == "evaluations":
        st.markdown('<div class="page-header"><div><div class="page-header-title">📊 Performance Evaluations</div><div class="page-header-sub">View your evaluation history and scores</div></div></div>', unsafe_allow_html=True)

        evals = get_evaluations(uid)
        if not evals:
            st.info("No evaluations yet. Check back after your first review!")
        else:
            # Latest radar
            col1, col2 = st.columns([1, 1])
            with col1:
                st.plotly_chart(evaluation_radar(evals[0]), use_container_width=True)
            with col2:
                eval_df = get_evaluation_trend(uid)
                st.plotly_chart(evaluation_trend_line(eval_df), use_container_width=True)

            st.markdown('<div class="section-title">📋 Evaluation History</div>', unsafe_allow_html=True)
            for e in evals:
                with st.expander(f"📅 Evaluation — {e['eval_date']}  |  Overall: {e['overall_score']}/10"):
                    metrics = [("Communication", e.get("communication")),
                               ("Technical Skills", e.get("technical_skills")),
                               ("Teamwork", e.get("teamwork")),
                               ("Initiative", e.get("initiative")),
                               ("Punctuality", e.get("punctuality")),
                               ("Quality of Work", e.get("quality_of_work"))]
                    cols = st.columns(3)
                    for i, (m, v) in enumerate(metrics):
                        with cols[i % 3]:
                            color = "green" if (v or 0) >= 7 else "orange" if (v or 0) >= 5 else "red"
                            st.metric(m, f"{v}/10" if v else "N/A")
                    if e.get("feedback"):
                        st.info(f"💬 Feedback: {e['feedback']}")

    # ── SKILLS ────────────────────────────────────────────────────────────
    elif page == "skills":
        st.markdown('<div class="page-header"><div><div class="page-header-title">🎯 Skills & Proficiency</div><div class="page-header-sub">Track and update your technical & soft skills</div></div></div>', unsafe_allow_html=True)

        skills = get_skills(uid)
        col1, col2 = st.columns([1.5, 1])
        with col1:
            st.plotly_chart(skill_bar_chart(skills), use_container_width=True)
        with col2:
            st.markdown('<div class="section-title">➕ Update Skill</div>', unsafe_allow_html=True)
            with st.form("skill_form"):
                skill_name = st.selectbox("Skill", [
                    "Python", "SQL", "Machine Learning", "Statistics", "Deep Learning",
                    "NLP", "Data Visualization", "R", "Tableau", "Power BI",
                    "Communication", "Problem Solving", "Teamwork", "Research",
                    "Docker", "AWS", "Java", "JavaScript", "Excel"
                ])
                custom_skill = st.text_input("Or type a custom skill")
                proficiency = st.slider("Proficiency (1-10)", 1, 10, 5)
                notes = st.text_input("Notes (optional)")
                if st.form_submit_button("Save Skill", use_container_width=True):
                    final_skill = custom_skill.strip() if custom_skill.strip() else skill_name
                    upsert_skill(uid, final_skill, proficiency, notes)
                    st.success(f"✅ {final_skill} saved!")
                    st.rerun()

        # Skill table
        st.markdown('<div class="section-title">📋 All Skills</div>', unsafe_allow_html=True)
        for s in sorted(skills, key=lambda x: -x["proficiency"]):
            level_color = "success" if s["proficiency"] >= 7 else "warning" if s["proficiency"] >= 4 else "danger"
            st.markdown(f"""
            <div class="task-item">
                <div style="display:flex;justify-content:space-between;align-items:center">
                    <div>
                        <div class="task-title">🔷 {s['skill_name']}</div>
                        <div class="task-meta">Last updated: {s.get('assessed_date','N/A')}</div>
                    </div>
                    {badge(f"{s['proficiency']}/10", level_color)}
                </div>
                {progress_bar(s['proficiency']*10)}
            </div>""", unsafe_allow_html=True)

    # ── SUGGESTIONS ───────────────────────────────────────────────────────
    elif page == "suggestions":
        st.markdown('<div class="page-header"><div><div class="page-header-title">💡 Suggestions & Insights</div><div class="page-header-sub">Personalized AI-powered recommendations for your growth</div></div></div>', unsafe_allow_html=True)

        # AI generated
        st.markdown('<div class="section-title">🤖 AI-Generated Suggestions</div>', unsafe_allow_html=True)
        sugg = generate_suggestions(uid)
        for s in sugg:
            st.markdown(f'<div class="suggestion-card {s["priority"]}">{s["text"]}<br><small style="color:#64748b;margin-top:4px;display:block">Category: {s["category"]}</small></div>',
                        unsafe_allow_html=True)

        # Stored suggestions
        st.markdown('<div class="section-title">📋 Mentor Suggestions</div>', unsafe_allow_html=True)
        stored = get_suggestions(uid)
        if not stored:
            st.info("No mentor suggestions yet.")
        for s in stored:
            priority = "info"
            st.markdown(f'<div class="suggestion-card {priority}">💬 {s["suggestion_text"]}<br><small style="color:#64748b">Category: {s["category"]} · {s["created_at"][:10]}</small></div>',
                        unsafe_allow_html=True)

    # ── ANNOUNCEMENTS ─────────────────────────────────────────────────────
    elif page == "announcements":
        st.markdown('<div class="page-header"><div><div class="page-header-title">📢 Announcements</div><div class="page-header-sub">Important updates from admin</div></div></div>', unsafe_allow_html=True)

        for ann in get_announcements():
            st.markdown(f"""
            <div class="announcement-card">
                <div style="display:flex;justify-content:space-between">
                    <div class="announcement-title">📌 {ann['title']}</div>
                    <div class="announcement-date">{ann['created_at'][:10]}</div>
                </div>
                <div style="margin-top:8px;color:#cbd5e1">{ann['content']}</div>
                <div style="margin-top:6px;font-size:0.75rem;color:#64748b">Posted by: {ann.get('admin_name','Admin')}</div>
            </div>""", unsafe_allow_html=True)
