import streamlit as st


def apply_styles():
    st.markdown("""
    <style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap');

    :root {
        --bg: #0a0f1e;
        --bg2: #0f172a;
        --card: #1e293b;
        --card2: #162032;
        --border: rgba(99,102,241,0.2);
        --primary: #6366f1;
        --primary-light: rgba(99,102,241,0.15);
        --success: #10b981;
        --warning: #f59e0b;
        --danger: #ef4444;
        --info: #3b82f6;
        --text: #e2e8f0;
        --text-muted: #94a3b8;
        --accent: #a78bfa;
    }

    html, body, .stApp {
        background-color: var(--bg) !important;
        color: var(--text) !important;
        font-family: 'Inter', sans-serif !important;
    }

    /* Hide Streamlit chrome */
    #MainMenu, footer, header { visibility: hidden; }
    .stDeployButton { display: none; }
    .block-container { padding-top: 1.5rem !important; padding-bottom: 2rem; max-width: 1400px; }

    /* ── LOGIN ── */
    .login-hero {
        text-align: center;
        padding: 4rem 1rem 2rem;
    }
    .login-badge {
        display: inline-block;
        background: var(--primary-light);
        border: 1px solid var(--border);
        border-radius: 50px;
        padding: 0.4rem 1.2rem;
        font-size: 0.85rem;
        font-weight: 600;
        color: var(--accent);
        letter-spacing: 0.05em;
        margin-bottom: 1.2rem;
    }
    .login-title {
        font-family: 'Space Grotesk', sans-serif !important;
        font-size: 3rem !important;
        font-weight: 700 !important;
        line-height: 1.15 !important;
        color: var(--text) !important;
        margin-bottom: 0.8rem !important;
    }
    .login-title span { color: var(--accent); }
    .login-subtitle { color: var(--text-muted); font-size: 1.1rem; margin-bottom: 2rem; }
    .login-card {
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 2rem;
        box-shadow: 0 20px 60px rgba(0,0,0,0.4);
    }

    /* ── SIDEBAR ── */
    [data-testid="stSidebar"] {
        background: var(--bg2) !important;
        border-right: 1px solid var(--border);
    }
    [data-testid="stSidebar"] .stButton button {
        background: transparent !important;
        color: var(--text-muted) !important;
        border: 1px solid var(--border) !important;
        border-radius: 8px !important;
        transition: all 0.2s;
    }
    [data-testid="stSidebar"] .stButton button:hover {
        background: var(--primary-light) !important;
        color: var(--text) !important;
        border-color: var(--primary) !important;
    }
    .sidebar-header {
        display: flex;
        align-items: center;
        gap: 12px;
        padding: 0.5rem 0;
    }
    .sidebar-avatar {
        width: 44px;
        height: 44px;
        border-radius: 50%;
        background: linear-gradient(135deg, var(--primary), var(--accent));
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.2rem;
        font-weight: 700;
        color: white;
    }
    .sidebar-name { font-weight: 600; font-size: 0.95rem; }
    .sidebar-role { font-size: 0.78rem; color: var(--text-muted); margin-top: 2px; }

    /* ── METRIC CARDS ── */
    .kpi-card {
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 1.2rem 1.4rem;
        position: relative;
        overflow: hidden;
        transition: transform 0.2s, box-shadow 0.2s;
    }
    .kpi-card:hover {
        transform: translateY(-2px);
        box-shadow: 0 8px 30px rgba(99,102,241,0.15);
    }
    .kpi-card::before {
        content: '';
        position: absolute;
        top: 0; left: 0; right: 0;
        height: 3px;
        border-radius: 14px 14px 0 0;
    }
    .kpi-card.primary::before { background: var(--primary); }
    .kpi-card.success::before { background: var(--success); }
    .kpi-card.warning::before { background: var(--warning); }
    .kpi-card.info::before    { background: var(--info); }
    .kpi-card.danger::before  { background: var(--danger); }
    .kpi-icon { font-size: 1.8rem; margin-bottom: 0.5rem; }
    .kpi-value {
        font-family: 'Space Grotesk', sans-serif;
        font-size: 2rem;
        font-weight: 700;
        line-height: 1;
        margin: 0.2rem 0;
    }
    .kpi-label { font-size: 0.8rem; color: var(--text-muted); text-transform: uppercase; letter-spacing: 0.08em; }
    .kpi-sub { font-size: 0.78rem; color: var(--text-muted); margin-top: 0.3rem; }

    /* ── SECTION HEADERS ── */
    .section-title {
        font-family: 'Space Grotesk', sans-serif;
        font-size: 1.2rem;
        font-weight: 600;
        color: var(--text);
        margin: 1.5rem 0 0.8rem;
        display: flex;
        align-items: center;
        gap: 8px;
    }
    .section-title::after {
        content: '';
        flex: 1;
        height: 1px;
        background: var(--border);
        margin-left: 8px;
    }

    /* ── CONTENT CARDS ── */
    .content-card {
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 14px;
        padding: 1.4rem;
        margin-bottom: 1rem;
    }

    /* ── PAGE HEADER ── */
    .page-header {
        background: linear-gradient(135deg, rgba(99,102,241,0.12), rgba(167,139,250,0.08));
        border: 1px solid var(--border);
        border-radius: 16px;
        padding: 1.5rem 2rem;
        margin-bottom: 1.5rem;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    .page-header-title {
        font-family: 'Space Grotesk', sans-serif;
        font-size: 1.6rem;
        font-weight: 700;
        margin: 0;
    }
    .page-header-sub { color: var(--text-muted); font-size: 0.9rem; margin-top: 0.3rem; }

    /* ── TASK CARDS ── */
    .task-item {
        background: var(--card2);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 1rem;
        margin-bottom: 0.6rem;
        position: relative;
    }
    .task-title { font-weight: 600; font-size: 0.95rem; }
    .task-meta { font-size: 0.78rem; color: var(--text-muted); margin-top: 0.2rem; }

    /* ── BADGES ── */
    .badge {
        display: inline-block;
        padding: 0.2em 0.6em;
        border-radius: 6px;
        font-size: 0.72rem;
        font-weight: 600;
        letter-spacing: 0.04em;
        text-transform: uppercase;
    }
    .badge-success { background: rgba(16,185,129,0.2); color: #10b981; }
    .badge-warning { background: rgba(245,158,11,0.2); color: #f59e0b; }
    .badge-info    { background: rgba(59,130,246,0.2); color: #3b82f6; }
    .badge-danger  { background: rgba(239,68,68,0.2);  color: #ef4444; }
    .badge-purple  { background: rgba(139,92,246,0.2); color: #8b5cf6; }

    /* ── SUGGESTION CARDS ── */
    .suggestion-card {
        background: var(--card);
        border-left: 4px solid var(--primary);
        border-radius: 0 10px 10px 0;
        padding: 1rem 1.2rem;
        margin-bottom: 0.7rem;
    }
    .suggestion-card.high  { border-color: var(--danger); }
    .suggestion-card.medium { border-color: var(--warning); }
    .suggestion-card.info  { border-color: var(--success); }

    /* ── ANNOUNCEMENT CARDS ── */
    .announcement-card {
        background: var(--card);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 1rem 1.2rem;
        margin-bottom: 0.6rem;
    }
    .announcement-title { font-weight: 600; font-size: 0.92rem; }
    .announcement-date { font-size: 0.75rem; color: var(--text-muted); }

    /* ── INTERN TABLE ── */
    .intern-row {
        background: var(--card2);
        border: 1px solid var(--border);
        border-radius: 10px;
        padding: 0.9rem 1.2rem;
        margin-bottom: 0.5rem;
        display: flex;
        align-items: center;
        gap: 1rem;
        cursor: pointer;
        transition: background 0.2s, border-color 0.2s;
    }
    .intern-row:hover {
        background: var(--primary-light);
        border-color: var(--primary);
    }

    /* ── PROGRESS BAR ── */
    .progress-wrap {
        background: rgba(255,255,255,0.08);
        border-radius: 999px;
        height: 8px;
        overflow: hidden;
        margin-top: 4px;
    }
    .progress-fill {
        height: 100%;
        border-radius: 999px;
        background: linear-gradient(90deg, var(--primary), var(--accent));
        transition: width 0.5s ease;
    }

    /* ── STREAMLIT OVERRIDES ── */
    .stButton button {
        background: var(--primary) !important;
        color: white !important;
        border: none !important;
        border-radius: 8px !important;
        font-weight: 600 !important;
        transition: opacity 0.2s !important;
    }
    .stButton button:hover { opacity: 0.9 !important; }
    .stButton button[kind="secondary"] {
        background: transparent !important;
        border: 1px solid var(--border) !important;
        color: var(--text) !important;
    }

    .stTextInput input, .stTextArea textarea, .stSelectbox select,
    [data-baseweb="select"] > div {
        background: var(--card2) !important;
        border: 1px solid var(--border) !important;
        color: var(--text) !important;
        border-radius: 8px !important;
    }
    .stSlider [data-baseweb="slider"] { background: transparent !important; }
    .stTabs [data-baseweb="tab-list"] {
        background: var(--card2) !important;
        border-radius: 10px !important;
        padding: 4px !important;
        gap: 4px !important;
    }
    .stTabs [data-baseweb="tab"] {
        background: transparent !important;
        color: var(--text-muted) !important;
        border-radius: 7px !important;
    }
    .stTabs [aria-selected="true"] {
        background: var(--primary) !important;
        color: white !important;
    }
    [data-testid="stMetricValue"] {
        font-family: 'Space Grotesk', sans-serif !important;
        font-size: 1.8rem !important;
        font-weight: 700 !important;
        color: var(--text) !important;
    }
    [data-testid="stExpander"] {
        background: var(--card) !important;
        border: 1px solid var(--border) !important;
        border-radius: 10px !important;
    }
    .stAlert {
        background: var(--card) !important;
        border-radius: 10px !important;
        border: 1px solid var(--border) !important;
        color: var(--text) !important;
    }
    hr { border-color: var(--border) !important; }
    label { color: var(--text-muted) !important; font-size: 0.82rem !important; }
    h1, h2, h3, h4, h5, h6 {
        font-family: 'Space Grotesk', sans-serif !important;
        color: var(--text) !important;
    }
    p, li, span { color: var(--text) !important; }
    </style>
    """, unsafe_allow_html=True)
