import sqlite3
import hashlib
import random
from datetime import datetime, timedelta
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from database.schema import get_connection, initialize_db


def hash_password(password):
    return hashlib.sha256(password.encode()).hexdigest()


def seed():
    initialize_db()
    conn = get_connection()
    c = conn.cursor()

    # Admin user
    try:
        c.execute("INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
                  ("admin", hash_password("admin123"), "admin"))
        admin_id = c.lastrowid
    except:
        admin_id = conn.execute("SELECT id FROM users WHERE username='admin'").fetchone()[0]

    # Intern users
    interns_data = [
        ("arjun_k", "intern123", "Arjun Kumar", "arjun@example.com", "9876543210",
         "Data Science", "Dr. Priya", "2024-01-15", "2024-07-15",
         "Python,Machine Learning,SQL,Pandas", "Passionate ML enthusiast"),
        ("sneha_r", "intern123", "Sneha Rao", "sneha@example.com", "9876543211",
         "Analytics", "Mr. Karthik", "2024-02-01", "2024-08-01",
         "R,Statistics,Tableau,Excel", "Data analyst with strong stats background"),
        ("rahul_m", "intern123", "Rahul Mehta", "rahul@example.com", "9876543212",
         "Engineering", "Ms. Divya", "2024-01-20", "2024-07-20",
         "Java,Python,Docker,AWS", "Backend developer"),
        ("ananya_s", "intern123", "Ananya Singh", "ananya@example.com", "9876543213",
         "Data Science", "Dr. Priya", "2024-03-01", "2024-09-01",
         "Python,Deep Learning,TensorFlow,NLP", "AI researcher"),
        ("vikram_n", "intern123", "Vikram Nair", "vikram@example.com", "9876543214",
         "Analytics", "Mr. Karthik", "2024-02-15", "2024-08-15",
         "SQL,Power BI,Python,Excel", "Business intelligence analyst"),
    ]

    intern_ids = []
    for uname, pwd, name, email, phone, dept, mentor, sd, ed, skills, bio in interns_data:
        try:
            c.execute("INSERT INTO users (username, password_hash, role) VALUES (?,?,?)",
                      (uname, hash_password(pwd), "intern"))
            uid = c.lastrowid
        except:
            uid = conn.execute("SELECT id FROM users WHERE username=?", (uname,)).fetchone()[0]

        c.execute("""
            INSERT OR REPLACE INTO intern_profiles
            (user_id, full_name, email, phone, department, mentor, start_date, end_date, skills, bio)
            VALUES (?,?,?,?,?,?,?,?,?,?)
        """, (uid, name, email, phone, dept, mentor, sd, ed, skills, bio))
        intern_ids.append(uid)

    # Attendance for last 60 days
    statuses = ['present', 'present', 'present', 'present', 'late', 'absent', 'half_day']
    for uid in intern_ids:
        for i in range(60):
            date = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
            weekday = (datetime.now() - timedelta(days=i)).weekday()
            if weekday >= 5:
                continue
            status = random.choice(statuses)
            check_in = None
            check_out = None
            if status in ('present', 'late', 'half_day'):
                hour = 9 if status == 'present' else (10 if status == 'late' else 9)
                check_in = f"{hour}:{random.randint(0,59):02d} AM"
                check_out = f"{random.randint(5,7)}:{random.randint(0,59):02d} PM"
            try:
                c.execute("INSERT INTO attendance (user_id, date, status, check_in, check_out) VALUES (?,?,?,?,?)",
                          (uid, date, status, check_in, check_out))
            except:
                pass

    # Tasks
    task_templates = [
        ("Data Preprocessing Pipeline", "Clean and preprocess raw datasets", "Data Science", "high"),
        ("EDA Report", "Exploratory data analysis on sales data", "Analytics", "medium"),
        ("Model Training", "Train classification model on customer data", "ML", "high"),
        ("Dashboard Design", "Design KPI dashboard in Streamlit", "Frontend", "medium"),
        ("SQL Optimization", "Optimize slow database queries", "Backend", "low"),
        ("Literature Review", "Review recent papers on NLP", "Research", "medium"),
        ("API Integration", "Integrate third-party data API", "Backend", "high"),
        ("Weekly Report", "Compile weekly progress report", "Management", "low"),
        ("Feature Engineering", "Create new features for ML model", "ML", "high"),
        ("Presentation Prep", "Prepare mid-term presentation slides", "Management", "medium"),
    ]
    statuses_task = ['todo', 'in_progress', 'in_progress', 'review', 'done']
    for uid in intern_ids:
        selected = random.sample(task_templates, 6)
        for title, desc, cat, priority in selected:
            status = random.choice(statuses_task)
            progress = 0 if status == 'todo' else (random.randint(20, 80) if status == 'in_progress'
                        else (random.randint(85, 99) if status == 'review' else 100))
            due = (datetime.now() + timedelta(days=random.randint(-10, 30))).strftime("%Y-%m-%d")
            c.execute("""
                INSERT INTO tasks (user_id, title, description, category, priority, status, progress, due_date)
                VALUES (?,?,?,?,?,?,?,?)
            """, (uid, title, desc, cat, priority, status, progress, due))

    # Evaluations (monthly)
    for uid in intern_ids:
        for month_offset in range(1, 4):
            eval_date = (datetime.now() - timedelta(days=30 * month_offset)).strftime("%Y-%m-%d")
            scores = {
                "communication": random.randint(6, 10),
                "technical_skills": random.randint(5, 10),
                "teamwork": random.randint(6, 10),
                "initiative": random.randint(5, 10),
                "punctuality": random.randint(6, 10),
                "quality_of_work": random.randint(6, 10),
            }
            overall = sum(scores.values()) / len(scores)
            c.execute("""
                INSERT INTO evaluations
                (user_id, evaluator_id, eval_date, communication, technical_skills,
                 teamwork, initiative, punctuality, quality_of_work, overall_score, feedback)
                VALUES (?,?,?,?,?,?,?,?,?,?,?)
            """, (uid, admin_id, eval_date, scores["communication"], scores["technical_skills"],
                  scores["teamwork"], scores["initiative"], scores["punctuality"],
                  scores["quality_of_work"], overall,
                  "Good progress. Keep up the momentum and focus on weak areas."))

    # Skill assessments
    all_skills = ["Python", "SQL", "Machine Learning", "Statistics", "Communication",
                  "Problem Solving", "Teamwork", "Data Visualization", "Deep Learning", "Research"]
    for uid in intern_ids:
        for skill in random.sample(all_skills, 6):
            c.execute("""
                INSERT INTO skill_assessments (user_id, skill_name, proficiency, assessed_date)
                VALUES (?,?,?,?)
            """, (uid, skill, random.randint(4, 10), datetime.now().strftime("%Y-%m-%d")))

    # Announcements
    announcements = [
        ("Mid-term Review", "All interns must submit mid-term project report by end of month."),
        ("Hackathon 2024", "Company hackathon on July 20. Register by July 15."),
        ("Mentorship Session", "Group mentorship session scheduled for next Friday 3PM."),
    ]
    for title, content in announcements:
        c.execute("INSERT INTO announcements (admin_id, title, content) VALUES (?,?,?)",
                  (admin_id, title, content))

    # Suggestions
    suggestions_pool = [
        ("Focus on improving your SQL query optimization skills.", "Technical"),
        ("Consider taking an online course on Deep Learning fundamentals.", "Learning"),
        ("Your attendance has improved — great consistency this week!", "Positive"),
        ("Try contributing to open-source projects to build your portfolio.", "Career"),
        ("Schedule a 1-on-1 with your mentor to discuss career goals.", "Mentorship"),
        ("Work on communication skills — participate more in team meetings.", "Soft Skills"),
    ]
    for uid in intern_ids:
        for text, cat in random.sample(suggestions_pool, 3):
            c.execute("INSERT INTO suggestions (user_id, suggestion_text, category) VALUES (?,?,?)",
                      (uid, text, cat))

    conn.commit()
    conn.close()
    print("Seed data inserted successfully!")
    print("\n=== LOGIN CREDENTIALS ===")
    print("Admin: username=admin, password=admin123")
    print("Intern 1: username=arjun_k, password=intern123")
    print("Intern 2: username=sneha_r, password=intern123")
    print("Intern 3: username=rahul_m, password=intern123")
    print("Intern 4: username=ananya_s, password=intern123")
    print("Intern 5: username=vikram_n, password=intern123")


if __name__ == "__main__":
    seed()
