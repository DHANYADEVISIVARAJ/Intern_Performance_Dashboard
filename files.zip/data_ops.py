import os
import sys
from datetime import datetime

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from database.schema import get_connection


# ─── PROFILE ─────────────────────────────────────────────────────────────────

def get_profile(user_id: int):
    conn = get_connection()
    row = conn.execute("""
        SELECT ip.*, u.username FROM intern_profiles ip
        JOIN users u ON u.id = ip.user_id
        WHERE ip.user_id=?
    """, (user_id,)).fetchone()
    conn.close()
    return dict(row) if row else None


def update_profile(user_id: int, data: dict):
    conn = get_connection()
    fields = ["full_name", "email", "phone", "department", "mentor",
              "start_date", "end_date", "skills", "bio", "github_url", "linkedin_url"]
    set_clause = ", ".join(f"{f}=?" for f in fields if f in data)
    values = [data[f] for f in fields if f in data]
    values.append(datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
    values.append(user_id)
    conn.execute(f"UPDATE intern_profiles SET {set_clause}, updated_at=? WHERE user_id=?", values)
    conn.commit()
    conn.close()


# ─── ATTENDANCE ───────────────────────────────────────────────────────────────

def get_attendance(user_id: int, days: int = 30):
    conn = get_connection()
    rows = conn.execute("""
        SELECT * FROM attendance WHERE user_id=?
        ORDER BY date DESC LIMIT ?
    """, (user_id, days)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def mark_attendance(user_id: int, date: str, status: str, check_in: str = None,
                    check_out: str = None, notes: str = ""):
    conn = get_connection()
    conn.execute("""
        INSERT OR REPLACE INTO attendance (user_id, date, status, check_in, check_out, notes)
        VALUES (?,?,?,?,?,?)
    """, (user_id, date, status, check_in, check_out, notes))
    conn.commit()
    conn.close()


def get_attendance_summary(user_id: int):
    conn = get_connection()
    rows = conn.execute("SELECT status, COUNT(*) as cnt FROM attendance WHERE user_id=? GROUP BY status",
                        (user_id,)).fetchall()
    conn.close()
    summary = {r["status"]: r["cnt"] for r in rows}
    total = sum(summary.values())
    present = summary.get("present", 0)
    rate = round((present / total * 100), 1) if total > 0 else 0
    return {"summary": summary, "total": total, "attendance_rate": rate}


def get_all_attendance_today():
    conn = get_connection()
    today = datetime.now().strftime("%Y-%m-%d")
    rows = conn.execute("""
        SELECT u.id, ip.full_name, ip.department, a.status, a.check_in, a.check_out
        FROM users u
        LEFT JOIN intern_profiles ip ON ip.user_id = u.id
        LEFT JOIN attendance a ON a.user_id = u.id AND a.date=?
        WHERE u.role='intern'
    """, (today,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ─── TASKS ────────────────────────────────────────────────────────────────────

def get_tasks(user_id: int):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM tasks WHERE user_id=? ORDER BY created_at DESC",
                        (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_task(user_id: int, title: str, description: str, category: str,
             priority: str, due_date: str):
    conn = get_connection()
    conn.execute("""
        INSERT INTO tasks (user_id, title, description, category, priority, due_date)
        VALUES (?,?,?,?,?,?)
    """, (user_id, title, description, category, priority, due_date))
    conn.commit()
    conn.close()


def update_task(task_id: int, status: str, progress: int):
    conn = get_connection()
    conn.execute("""
        UPDATE tasks SET status=?, progress=?, updated_at=CURRENT_TIMESTAMP
        WHERE id=?
    """, (status, progress, task_id))
    conn.commit()
    conn.close()


def delete_task(task_id: int):
    conn = get_connection()
    conn.execute("DELETE FROM tasks WHERE id=?", (task_id,))
    conn.commit()
    conn.close()


def get_task_summary(user_id: int):
    conn = get_connection()
    rows = conn.execute("SELECT status, COUNT(*) as cnt FROM tasks WHERE user_id=? GROUP BY status",
                        (user_id,)).fetchall()
    conn.close()
    return {r["status"]: r["cnt"] for r in rows}


# ─── EVALUATIONS ─────────────────────────────────────────────────────────────

def get_evaluations(user_id: int):
    conn = get_connection()
    rows = conn.execute("""
        SELECT e.*, u.username as evaluator_name
        FROM evaluations e
        LEFT JOIN users u ON u.id = e.evaluator_id
        WHERE e.user_id=? ORDER BY e.eval_date DESC
    """, (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_evaluation(user_id: int, evaluator_id: int, eval_date: str, scores: dict, feedback: str):
    overall = sum(scores.values()) / len(scores)
    conn = get_connection()
    conn.execute("""
        INSERT INTO evaluations
        (user_id, evaluator_id, eval_date, communication, technical_skills,
         teamwork, initiative, punctuality, quality_of_work, overall_score, feedback)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)
    """, (user_id, evaluator_id, eval_date,
          scores.get("communication"), scores.get("technical_skills"),
          scores.get("teamwork"), scores.get("initiative"),
          scores.get("punctuality"), scores.get("quality_of_work"),
          round(overall, 2), feedback))
    conn.commit()
    conn.close()


# ─── SKILLS ──────────────────────────────────────────────────────────────────

def get_skills(user_id: int):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM skill_assessments WHERE user_id=?", (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def upsert_skill(user_id: int, skill_name: str, proficiency: int, notes: str = ""):
    conn = get_connection()
    existing = conn.execute("SELECT id FROM skill_assessments WHERE user_id=? AND skill_name=?",
                            (user_id, skill_name)).fetchone()
    today = datetime.now().strftime("%Y-%m-%d")
    if existing:
        conn.execute("UPDATE skill_assessments SET proficiency=?, notes=?, assessed_date=? WHERE id=?",
                     (proficiency, notes, today, existing["id"]))
    else:
        conn.execute("INSERT INTO skill_assessments (user_id, skill_name, proficiency, assessed_date, notes) VALUES (?,?,?,?,?)",
                     (user_id, skill_name, proficiency, today, notes))
    conn.commit()
    conn.close()


# ─── ANNOUNCEMENTS ───────────────────────────────────────────────────────────

def get_announcements():
    conn = get_connection()
    rows = conn.execute("""
        SELECT a.*, u.username as admin_name FROM announcements a
        LEFT JOIN users u ON u.id = a.admin_id
        ORDER BY a.created_at DESC LIMIT 10
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_announcement(admin_id: int, title: str, content: str):
    conn = get_connection()
    conn.execute("INSERT INTO announcements (admin_id, title, content) VALUES (?,?,?)",
                 (admin_id, title, content))
    conn.commit()
    conn.close()


# ─── SUGGESTIONS ─────────────────────────────────────────────────────────────

def get_suggestions(user_id: int):
    conn = get_connection()
    rows = conn.execute("SELECT * FROM suggestions WHERE user_id=? ORDER BY created_at DESC",
                        (user_id,)).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def add_suggestion(user_id: int, text: str, category: str):
    conn = get_connection()
    conn.execute("INSERT INTO suggestions (user_id, suggestion_text, category) VALUES (?,?,?)",
                 (user_id, text, category))
    conn.commit()
    conn.close()


def mark_suggestion_read(suggestion_id: int):
    conn = get_connection()
    conn.execute("UPDATE suggestions SET is_read=1 WHERE id=?", (suggestion_id,))
    conn.commit()
    conn.close()


# ─── ADMIN ───────────────────────────────────────────────────────────────────

def get_all_interns():
    conn = get_connection()
    rows = conn.execute("""
        SELECT u.id, u.username, u.created_at, ip.*
        FROM users u
        JOIN intern_profiles ip ON ip.user_id = u.id
        WHERE u.role='intern'
        ORDER BY ip.full_name
    """).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_intern_full_report(user_id: int):
    return {
        "profile": get_profile(user_id),
        "attendance_summary": get_attendance_summary(user_id),
        "attendance": get_attendance(user_id, 30),
        "tasks": get_tasks(user_id),
        "task_summary": get_task_summary(user_id),
        "evaluations": get_evaluations(user_id),
        "skills": get_skills(user_id),
        "suggestions": get_suggestions(user_id),
    }
