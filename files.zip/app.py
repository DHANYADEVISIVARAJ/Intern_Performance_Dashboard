import streamlit as st
import os
import sys

# Make sure all modules can be found
sys.path.insert(0, os.path.dirname(__file__))

from database.schema import initialize_db
from backend.auth import authenticate
from frontend.styles import apply_styles
from frontend.intern_module import render_intern_dashboard
from frontend.admin_module import render_admin_dashboard

# ─── PAGE CONFIG ─────────────────────────────────────────────────────────────
st.set_page_config(
    page_title="InternIQ — Performance Analytics",
    page_icon="🎯",
    layout="wide",
    initial_sidebar_state="expanded",
)

# ─── INIT DB ─────────────────────────────────────────────────────────────────
initialize_db()

# ─── SESSION DEFAULTS ────────────────────────────────────────────────────────
if "user" not in st.session_state:
    st.session_state.user = None
if "page" not in st.session_state:
    st.session_state.page = "login"

# ─── APPLY GLOBAL STYLES ─────────────────────────────────────────────────────
apply_styles()


# ─── LOGIN PAGE ──────────────────────────────────────────────────────────────
def render_login():
    st.markdown("""
    <div class="login-hero">
        <div class="login-badge">🎯 InternIQ</div>
        <h1 class="login-title">Performance Analytics<br><span>& Insights Dashboard</span></h1>
        <p class="login-subtitle">Track growth. Measure impact. Unlock potential.</p>
    </div>
    """, unsafe_allow_html=True)

    col1, col2, col3 = st.columns([1, 1.2, 1])
    with col2:
        st.markdown('<div class="login-card">', unsafe_allow_html=True)
        st.markdown("### 🔐 Sign In")

        tab1, tab2 = st.tabs(["Login", "Register as Intern"])

        with tab1:
            username = st.text_input("Username", placeholder="Enter your username", key="login_user")
            password = st.text_input("Password", type="password", placeholder="••••••••", key="login_pass")
            if st.button("Sign In →", use_container_width=True, type="primary"):
                user = authenticate(username, password)
                if user:
                    st.session_state.user = user
                    st.session_state.page = "dashboard"
                    st.rerun()
                else:
                    st.error("❌ Invalid credentials. Please try again.")
            st.markdown("---")
            st.caption("**Demo Credentials:**")
            st.caption("🔴 Admin: `admin` / `admin123`")
            st.caption("🔵 Intern: `arjun_k` / `intern123`")

        with tab2:
            from backend.auth import register_intern
            rn = st.text_input("Username*", key="reg_uname")
            rp = st.text_input("Password*", type="password", key="reg_pass")
            rname = st.text_input("Full Name*", key="reg_name")
            remail = st.text_input("Email*", key="reg_email")
            rdept = st.selectbox("Department", ["Data Science", "Analytics", "Engineering",
                                                 "Design", "Marketing", "Operations"], key="reg_dept")
            rstart = st.date_input("Start Date", key="reg_start")
            rend = st.date_input("End Date", key="reg_end")
            rmentor = st.text_input("Mentor Name", key="reg_mentor")
            rphone = st.text_input("Phone", key="reg_phone")
            if st.button("Create Account →", use_container_width=True):
                if rn and rp and rname and remail:
                    ok, msg = register_intern(rn, rp, rname, remail, rdept,
                                              str(rstart), str(rend), rmentor, rphone)
                    if ok:
                        st.success(f"✅ {msg} You can now log in!")
                    else:
                        st.error(f"❌ {msg}")
                else:
                    st.warning("Please fill all required fields.")
        st.markdown('</div>', unsafe_allow_html=True)


# ─── MAIN ROUTER ─────────────────────────────────────────────────────────────
def main():
    if st.session_state.user is None:
        render_login()
    else:
        user = st.session_state.user

        # Sidebar
        with st.sidebar:
            st.markdown(f"""
            <div class="sidebar-header">
                <div class="sidebar-avatar">{user['username'][0].upper()}</div>
                <div>
                    <div class="sidebar-name">{user['username']}</div>
                    <div class="sidebar-role">{'🔴 Admin' if user['role']=='admin' else '🔵 Intern'}</div>
                </div>
            </div>
            """, unsafe_allow_html=True)
            st.divider()

            if st.button("🚪 Logout", use_container_width=True):
                st.session_state.user = None
                st.session_state.page = "login"
                st.rerun()

        if user["role"] == "admin":
            render_admin_dashboard(user)
        else:
            render_intern_dashboard(user)


if __name__ == "__main__":
    main()
