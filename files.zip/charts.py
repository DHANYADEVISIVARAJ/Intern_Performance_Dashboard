import plotly.graph_objects as go
import plotly.express as px
import pandas as pd
import numpy as np

COLORS = {
    "primary": "#6366f1",
    "success": "#10b981",
    "warning": "#f59e0b",
    "danger": "#ef4444",
    "info": "#3b82f6",
    "purple": "#8b5cf6",
    "bg": "#0f172a",
    "card": "#1e293b",
    "text": "#e2e8f0",
}

CHART_LAYOUT = dict(
    paper_bgcolor="rgba(0,0,0,0)",
    plot_bgcolor="rgba(0,0,0,0)",
    font=dict(color=COLORS["text"], family="Inter, sans-serif"),
    margin=dict(l=20, r=20, t=40, b=20),
)


def attendance_pie(summary: dict):
    labels = list(summary.keys())
    values = list(summary.values())
    colors = [COLORS["success"], COLORS["danger"], COLORS["warning"], COLORS["info"]]
    fig = go.Figure(go.Pie(
        labels=labels, values=values,
        hole=0.55,
        marker=dict(colors=colors[:len(labels)], line=dict(color="#0f172a", width=2)),
        textinfo="percent+label",
        textfont=dict(size=13),
    ))
    fig.update_layout(**CHART_LAYOUT, title="Attendance Breakdown",
                      showlegend=False, height=300)
    return fig


def attendance_trend_chart(df: pd.DataFrame):
    if df.empty:
        return go.Figure()
    fig = go.Figure()
    status_color = {"present": COLORS["success"], "absent": COLORS["danger"],
                    "late": COLORS["warning"], "half_day": COLORS["info"]}
    for status in df["status"].unique():
        mask = df["status"] == status
        fig.add_trace(go.Scatter(
            x=df[mask]["date"], y=[1] * mask.sum(),
            mode="markers",
            marker=dict(color=status_color.get(status, COLORS["info"]), size=10, symbol="circle"),
            name=status.capitalize()
        ))
    fig.add_trace(go.Scatter(
        x=df["date"], y=df["rolling_rate"],
        mode="lines", name="Rolling Attendance %",
        line=dict(color=COLORS["primary"], width=2.5, dash="solid"),
        yaxis="y2"
    ))
    fig.update_layout(
        **CHART_LAYOUT,
        title="Attendance Trend (Last 30 Days)",
        yaxis=dict(visible=False),
        yaxis2=dict(title="Attendance %", overlaying="y", side="right",
                    range=[0, 110], showgrid=False),
        height=280,
        legend=dict(orientation="h", y=-0.2)
    )
    return fig


def task_status_bar(task_summary: dict):
    statuses = ["todo", "in_progress", "review", "done"]
    labels = ["To Do", "In Progress", "Review", "Done"]
    colors = [COLORS["info"], COLORS["warning"], COLORS["purple"], COLORS["success"]]
    values = [task_summary.get(s, 0) for s in statuses]
    fig = go.Figure(go.Bar(
        x=labels, y=values,
        marker=dict(color=colors, line=dict(color="rgba(0,0,0,0)")),
        text=values, textposition="auto",
    ))
    fig.update_layout(**CHART_LAYOUT, title="Task Status Distribution", height=260,
                      xaxis=dict(showgrid=False), yaxis=dict(showgrid=False))
    return fig


def evaluation_radar(eval_row: dict):
    categories = ["Communication", "Technical", "Teamwork", "Initiative", "Punctuality", "Quality"]
    keys = ["communication", "technical_skills", "teamwork", "initiative", "punctuality", "quality_of_work"]
    values = [eval_row.get(k, 0) for k in keys]
    values += values[:1]
    cats = categories + categories[:1]
    fig = go.Figure(go.Scatterpolar(
        r=values, theta=cats,
        fill="toself",
        fillcolor=f"rgba(99,102,241,0.25)",
        line=dict(color=COLORS["primary"], width=2),
        marker=dict(color=COLORS["primary"], size=6),
    ))
    fig.update_layout(
        **CHART_LAYOUT,
        polar=dict(
            bgcolor="rgba(30,41,59,0.5)",
            radialaxis=dict(visible=True, range=[0, 10], color=COLORS["text"],
                            gridcolor="rgba(255,255,255,0.1)"),
            angularaxis=dict(color=COLORS["text"], gridcolor="rgba(255,255,255,0.1)")
        ),
        title="Performance Radar",
        height=350,
        showlegend=False
    )
    return fig


def evaluation_trend_line(df: pd.DataFrame):
    if df.empty:
        return go.Figure()
    metrics = ["communication", "technical_skills", "teamwork", "initiative",
               "punctuality", "quality_of_work", "overall_score"]
    metric_labels = ["Communication", "Technical", "Teamwork", "Initiative",
                     "Punctuality", "Quality", "Overall"]
    colors_list = [COLORS["info"], COLORS["warning"], COLORS["success"], COLORS["purple"],
                   COLORS["danger"], COLORS["primary"], "#f97316"]

    fig = go.Figure()
    for metric, label, color in zip(metrics, metric_labels, colors_list):
        if metric in df.columns:
            visible = True if metric == "overall_score" else "legendonly"
            fig.add_trace(go.Scatter(
                x=df["eval_date"], y=df[metric],
                mode="lines+markers", name=label,
                line=dict(color=color, width=2),
                visible=visible
            ))
    fig.update_layout(
        **CHART_LAYOUT,
        title="Evaluation Trend Over Time",
        yaxis=dict(range=[0, 10.5], showgrid=True,
                   gridcolor="rgba(255,255,255,0.05)"),
        height=320,
        legend=dict(orientation="h", y=-0.25, font=dict(size=10))
    )
    return fig


def skill_bar_chart(skills: list):
    if not skills:
        return go.Figure()
    df = pd.DataFrame(skills).sort_values("proficiency", ascending=True)
    colors = [COLORS["danger"] if p < 4 else COLORS["warning"] if p < 7
              else COLORS["success"] for p in df["proficiency"]]
    fig = go.Figure(go.Bar(
        x=df["proficiency"], y=df["skill_name"],
        orientation="h",
        marker=dict(color=colors, line=dict(color="rgba(0,0,0,0)")),
        text=df["proficiency"].astype(str) + "/10",
        textposition="auto",
    ))
    fig.update_layout(
        **CHART_LAYOUT,
        title="Skill Proficiency",
        xaxis=dict(range=[0, 11], showgrid=False),
        yaxis=dict(showgrid=False),
        height=max(250, len(skills) * 36),
    )
    return fig


def overall_gauge(score: float):
    color = COLORS["danger"] if score < 40 else COLORS["warning"] if score < 70 else COLORS["success"]
    fig = go.Figure(go.Indicator(
        mode="gauge+number+delta",
        value=score,
        delta={"reference": 70, "valueformat": ".1f"},
        gauge={
            "axis": {"range": [0, 100], "tickcolor": COLORS["text"]},
            "bar": {"color": color, "thickness": 0.3},
            "bgcolor": "rgba(30,41,59,0.8)",
            "steps": [
                {"range": [0, 40], "color": "rgba(239,68,68,0.1)"},
                {"range": [40, 70], "color": "rgba(245,158,11,0.1)"},
                {"range": [70, 100], "color": "rgba(16,185,129,0.1)"},
            ],
            "threshold": {"line": {"color": "white", "width": 3}, "value": 70},
        },
        number={"suffix": "%", "font": {"size": 36, "color": color}},
        title={"text": "Overall Score", "font": {"size": 14, "color": COLORS["text"]}},
        domain={"x": [0, 1], "y": [0, 1]},
    ))
    fig.update_layout(**CHART_LAYOUT, height=280)
    return fig


def department_bar(dept_data: list):
    df = pd.DataFrame(dept_data)
    if df.empty:
        return go.Figure()
    fig = px.bar(df, x="department", y="cnt", color="department",
                 color_discrete_sequence=px.colors.qualitative.Set3,
                 text="cnt")
    fig.update_layout(**CHART_LAYOUT, title="Interns by Department",
                      showlegend=False, height=280,
                      xaxis=dict(showgrid=False), yaxis=dict(showgrid=False))
    return fig


def top_performers_chart(performers: list):
    if not performers:
        return go.Figure()
    df = pd.DataFrame(performers).sort_values("avg_score")
    fig = go.Figure(go.Bar(
        x=df["avg_score"].round(2), y=df["full_name"],
        orientation="h",
        marker=dict(
            color=df["avg_score"],
            colorscale=[[0, COLORS["warning"]], [0.5, COLORS["info"]], [1, COLORS["success"]]],
            showscale=False,
        ),
        text=df["avg_score"].round(2).astype(str) + "/10",
        textposition="auto",
    ))
    fig.update_layout(
        **CHART_LAYOUT,
        title="Top Performers (Avg Evaluation Score)",
        xaxis=dict(range=[0, 11], showgrid=False),
        yaxis=dict(showgrid=False),
        height=280
    )
    return fig
