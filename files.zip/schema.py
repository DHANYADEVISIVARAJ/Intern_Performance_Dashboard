import sqlite3
import os

DB_PATH = os.path.join(os.path.dirname(__file__), "intern_analytics.db")


def get_connection():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    return conn


def initialize_db():
    conn = get_connection()
    c = conn.cursor()

    # Users table (both interns and admins)
    c.execute("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            password_hash TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('intern','admin')),
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Intern profiles
    c.execute("""
        CREATE TABLE IF NOT EXISTS intern_profiles (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER UNIQUE NOT NULL REFERENCES users(id),
            full_name TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT,
            department TEXT,
            mentor TEXT,
            start_date TEXT,
            end_date TEXT,
            skills TEXT,
            bio TEXT,
            photo_url TEXT,
            github_url TEXT,
            linkedin_url TEXT,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Attendance
    c.execute("""
        CREATE TABLE IF NOT EXISTS attendance (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            date TEXT NOT NULL,
            status TEXT NOT NULL CHECK(status IN ('present','absent','late','half_day')),
            check_in TEXT,
            check_out TEXT,
            notes TEXT,
            UNIQUE(user_id, date)
        )
    """)

    # Tasks / Projects
    c.execute("""
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            title TEXT NOT NULL,
            description TEXT,
            category TEXT,
            priority TEXT DEFAULT 'medium' CHECK(priority IN ('low','medium','high')),
            status TEXT DEFAULT 'todo' CHECK(status IN ('todo','in_progress','review','done')),
            progress INTEGER DEFAULT 0 CHECK(progress BETWEEN 0 AND 100),
            due_date TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Performance evaluations
    c.execute("""
        CREATE TABLE IF NOT EXISTS evaluations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            evaluator_id INTEGER REFERENCES users(id),
            eval_date TEXT NOT NULL,
            communication INTEGER CHECK(communication BETWEEN 1 AND 10),
            technical_skills INTEGER CHECK(technical_skills BETWEEN 1 AND 10),
            teamwork INTEGER CHECK(teamwork BETWEEN 1 AND 10),
            initiative INTEGER CHECK(initiative BETWEEN 1 AND 10),
            punctuality INTEGER CHECK(punctuality BETWEEN 1 AND 10),
            quality_of_work INTEGER CHECK(quality_of_work BETWEEN 1 AND 10),
            overall_score REAL,
            feedback TEXT,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Skill assessments
    c.execute("""
        CREATE TABLE IF NOT EXISTS skill_assessments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            skill_name TEXT NOT NULL,
            proficiency INTEGER CHECK(proficiency BETWEEN 1 AND 10),
            assessed_date TEXT,
            notes TEXT
        )
    """)

    # Announcements from admin
    c.execute("""
        CREATE TABLE IF NOT EXISTS announcements (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            admin_id INTEGER REFERENCES users(id),
            title TEXT NOT NULL,
            content TEXT NOT NULL,
            target TEXT DEFAULT 'all',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    # Suggestions / AI recommendations
    c.execute("""
        CREATE TABLE IF NOT EXISTS suggestions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id),
            suggestion_text TEXT NOT NULL,
            category TEXT,
            is_read INTEGER DEFAULT 0,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    """)

    conn.commit()
    conn.close()
    print("Database initialized successfully.")


if __name__ == "__main__":
    initialize_db()
