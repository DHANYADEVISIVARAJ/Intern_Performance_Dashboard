import pandas as pd
import numpy as np
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from database.schema import get_connection


def compute_kpis(user_id: int) -> dict:
    conn = get_connection()

    # Attendance rate
    att_rows = conn.execute(
        "SELECT status FROM attendance WHERE user_id=?", (user_id,)).fetchall()
    att_df = pd.DataFrame([dict(r) for r in att_rows]) if att_rows else pd.DataFrame(columns=["status"])
    total = len(att_df)
    present = len(att_df[att_df["status"] == "present"]) if total > 0 else 0
    late = len(att_df[att_df["status"] == "late"]) if total > 0 else 0
    att_rate = round((present + late * 0.5) / total * 100, 1) if total > 0 else 0

    # Task completion
    task_rows = conn.execute(
        "SELECT status, progress FROM tasks WHERE user_id=?", (user_id,)).fetchall()
    task_df = pd.DataFrame([dict(r) for r in task_rows]) if task_rows else pd.DataFrame(columns=["status", "progress"])
    task_total = len(task_df)
    task_done = len(task_df[task_df["status"] == "done"]) if task_total > 0 else 0
    task_rate = round(task_done / task_total * 100, 1) if task_total > 0 else 0
    avg_progress = round(task_df["progress"].mean(), 1) if task_total > 0 else 0

    # Latest evaluation score
    eval_row = conn.execute(
        "SELECT overall_score FROM evaluations WHERE user_id=? ORDER BY eval_date DESC LIMIT 1",
        (user_id,)).fetchone()
    latest_score = round(eval_row["overall_score"], 1) if eval_row else 0

    # Skill average
    skill_rows = conn.execute(
        "SELECT proficiency FROM skill_assessments WHERE user_id=?", (user_id,)).fetchall()
    skill_df = pd.DataFrame([dict(r) for r in skill_rows]) if skill_rows else pd.DataFrame(columns=["proficiency"])
    avg_skill = round(skill_df["proficiency"].mean(), 1) if not skill_df.empty else 0

    conn.close()

    overall_performance = round((att_rate * 0.25 + task_rate * 0.25 +
                                 latest_score * 10 * 0.3 + avg_skill * 10 * 0.2), 1)

    return {
        "attendance_rate": att_rate,
        "task_completion_rate": task_rate,
        "avg_task_progress": avg_progress,
        "latest_eval_score": latest_score,
        "avg_skill_level": avg_skill,
        "overall_performance": min(overall_performance, 100),
        "total_tasks": task_total,
        "completed_tasks": task_done,
        "total_attendance_days": total,
    }


def get_attendance_trend(user_id: int, days: int = 30) -> pd.DataFrame:
    conn = get_connection()
    rows = conn.execute("""
        SELECT date, status FROM attendance WHERE user_id=?
        ORDER BY date DESC LIMIT ?
    """, (user_id, days)).fetchall()
    conn.close()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame([dict(r) for r in rows])
    df["date"] = pd.to_datetime(df["date"])
    df = df.sort_values("date")
    df["is_present"] = df["status"].isin(["present", "late"]).astype(int)
    df["rolling_rate"] = df["is_present"].rolling(5, min_periods=1).mean() * 100
    return df


def get_task_progress_over_time(user_id: int) -> pd.DataFrame:
    conn = get_connection()
    rows = conn.execute("""
        SELECT created_at, updated_at, status, progress, title, category
        FROM tasks WHERE user_id=?
        ORDER BY created_at
    """, (user_id,)).fetchall()
    conn.close()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame([dict(r) for r in rows])
    df["created_at"] = pd.to_datetime(df["created_at"])
    return df


def get_evaluation_trend(user_id: int) -> pd.DataFrame:
    conn = get_connection()
    rows = conn.execute("""
        SELECT eval_date, communication, technical_skills, teamwork,
               initiative, punctuality, quality_of_work, overall_score
        FROM evaluations WHERE user_id=?
        ORDER BY eval_date
    """, (user_id,)).fetchall()
    conn.close()
    if not rows:
        return pd.DataFrame()
    df = pd.DataFrame([dict(r) for r in rows])
    df["eval_date"] = pd.to_datetime(df["eval_date"])
    return df


def get_department_comparison() -> pd.DataFrame:
    conn = get_connection()
    rows = conn.execute("""
        SELECT ip.department, ip.user_id,
               AVG(e.overall_score) as avg_eval
        FROM intern_profiles ip
        LEFT JOIN evaluations e ON e.user_id = ip.user_id
        GROUP BY ip.department, ip.user_id
    """).fetchall()
    conn.close()
    if not rows:
        return pd.DataFrame()
    return pd.DataFrame([dict(r) for r in rows])


def generate_suggestions(user_id: int) -> list:
    kpis = compute_kpis(user_id)
    suggestions = []

    if kpis["attendance_rate"] < 75:
        suggestions.append({
            "text": f"⚠️ Your attendance rate is {kpis['attendance_rate']}% — below the 75% threshold. Consistent attendance is critical for your performance evaluation.",
            "category": "Attendance",
            "priority": "high"
        })
    elif kpis["attendance_rate"] < 90:
        suggestions.append({
            "text": f"📅 Your attendance rate is {kpis['attendance_rate']}%. Try to improve consistency — aim for 90%+ to stand out.",
            "category": "Attendance",
            "priority": "medium"
        })

    if kpis["task_completion_rate"] < 50:
        suggestions.append({
            "text": "📋 Less than 50% of your tasks are completed. Prioritize pending work and break large tasks into smaller milestones.",
            "category": "Productivity",
            "priority": "high"
        })

    if kpis["latest_eval_score"] < 6:
        suggestions.append({
            "text": f"📊 Your latest evaluation score is {kpis['latest_eval_score']}/10. Discuss improvement areas with your mentor proactively.",
            "category": "Performance",
            "priority": "high"
        })

    if kpis["avg_skill_level"] < 6:
        suggestions.append({
            "text": "🎯 Your average skill proficiency is below 6/10. Consider enrolling in online courses on Coursera, edX, or NPTEL.",
            "category": "Skills",
            "priority": "medium"
        })

    # Positive feedback
    if kpis["attendance_rate"] >= 90:
        suggestions.append({
            "text": "🌟 Excellent attendance! Your consistent presence shows great dedication. Keep it up!",
            "category": "Positive",
            "priority": "info"
        })
    if kpis["task_completion_rate"] >= 80:
        suggestions.append({
            "text": f"✅ You've completed {kpis['task_completion_rate']}% of assigned tasks — outstanding productivity!",
            "category": "Positive",
            "priority": "info"
        })
    if kpis["overall_performance"] >= 75:
        suggestions.append({
            "text": "🚀 Your overall performance score is strong. Consider taking on a leadership role in an upcoming project.",
            "category": "Career",
            "priority": "info"
        })

    return suggestions


def get_admin_overview() -> dict:
    conn = get_connection()

    interns = conn.execute("""
        SELECT u.id, ip.full_name, ip.department FROM users u
        JOIN intern_profiles ip ON ip.user_id = u.id
        WHERE u.role='intern'
    """).fetchall()

    from datetime import datetime
    today = datetime.now().strftime("%Y-%m-%d")
    att_today = conn.execute("""
        SELECT status, COUNT(*) as cnt FROM attendance
        WHERE date=? GROUP BY status
    """, (today,)).fetchall()
    att_dict = {r["status"]: r["cnt"] for r in att_today}

    dept_counts = conn.execute("""
        SELECT department, COUNT(*) as cnt FROM intern_profiles GROUP BY department
    """).fetchall()

    eval_scores = conn.execute("""
        SELECT ip.full_name, AVG(e.overall_score) as avg_score
        FROM evaluations e
        JOIN intern_profiles ip ON ip.user_id = e.user_id
        GROUP BY e.user_id
        ORDER BY avg_score DESC
    """).fetchall()

    task_stats = conn.execute("""
        SELECT status, COUNT(*) as cnt FROM tasks GROUP BY status
    """).fetchall()

    conn.close()

    return {
        "total_interns": len(interns),
        "attendance_today": att_dict,
        "departments": [dict(r) for r in dept_counts],
        "top_performers": [dict(r) for r in eval_scores[:5]],
        "task_stats": {r["status"]: r["cnt"] for r in task_stats},
    }
