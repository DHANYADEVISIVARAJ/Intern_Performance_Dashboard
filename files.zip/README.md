# 🎯 InternIQ — Intern Performance Analytics & Insights Dashboard

A full-stack analytics platform for tracking, evaluating, and improving intern performance.

## 🏗️ Architecture

```
intern_dashboard/
├── app.py                    ← Main Streamlit entry point
├── requirements.txt
├── database/
│   ├── schema.py             ← SQLite schema & DB init
│   └── seed.py               ← Demo data seeder
├── backend/
│   ├── auth.py               ← Authentication (login, register, password)
│   └── data_ops.py           ← All CRUD operations
├── analytics/
│   ├── engine.py             ← KPI computation, trend analysis, AI suggestions
│   └── charts.py             ← Plotly chart builders
└── frontend/
    ├── styles.py             ← Global CSS (dark theme)
    ├── intern_module.py      ← Intern dashboard (7 pages)
    └── admin_module.py       ← Admin dashboard (7 pages + intern detail)
```

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Seed demo data
```bash
python database/seed.py
```

### 3. Run the app
```bash
streamlit run app.py
```

## 🔐 Demo Credentials

| Role   | Username   | Password   |
|--------|-----------|------------|
| Admin  | admin      | admin123   |
| Intern | arjun_k    | intern123  |
| Intern | sneha_r    | intern123  |
| Intern | rahul_m    | intern123  |
| Intern | ananya_s   | intern123  |
| Intern | vikram_n   | intern123  |

## 📦 Tech Stack

| Layer      | Technology        |
|------------|-------------------|
| Frontend   | Streamlit + CSS   |
| Backend    | Python 3.10+      |
| Database   | SQLite3           |
| Analytics  | Pandas + NumPy    |
| Charts     | Plotly            |

## 🗃️ Database Schema (SQLite)

| Table              | Purpose                          |
|--------------------|----------------------------------|
| `users`            | Auth credentials + roles         |
| `intern_profiles`  | Personal & contact information   |
| `attendance`       | Daily check-in/check-out records |
| `tasks`            | Project assignments & progress   |
| `evaluations`      | Monthly performance scores       |
| `skill_assessments`| Technical & soft skill ratings   |
| `announcements`    | Admin broadcast messages         |
| `suggestions`      | AI-generated & mentor feedback   |

## 👤 Intern Module — Pages

1. **🏠 Dashboard** — KPI overview, charts, AI suggestions, announcements
2. **👤 My Profile** — Edit personal info, skills, bio, social links
3. **📅 Attendance** — Mark daily attendance, view trends & history
4. **✅ My Tasks** — Add/update tasks with progress tracking
5. **📊 Evaluations** — View radar charts, evaluation history & trends
6. **🎯 Skills** — Update skill proficiency with visual bar charts
7. **💡 Suggestions** — AI-generated insights + mentor feedback
8. **📢 Announcements** — View admin messages

## 🔴 Admin Module — Pages

1. **🏠 Overview** — Company-wide KPIs, dept breakdown, top performers
2. **👥 All Interns** — Searchable/filterable intern list with quick stats
3. **📅 Attendance Today** — Real-time daily attendance board
4. **📊 Analytics** — Per-intern deep analytics with all charts
5. **📝 Evaluations** — Conduct evaluations with 6-dimension scoring
6. **📢 Announcements** — Post updates to all interns
7. **💡 Send Suggestions** — Send personalized feedback to interns

### 🔍 Intern Detail View
Click any intern name → Full profile, tabbed view:
- Overview (gauge + radar + profile info)
- Attendance history + trend charts
- All tasks with progress bars
- Evaluation history + add new eval
- Skills chart

## 📊 KPI Formula

```
Overall Performance = 
    (Attendance Rate × 0.25) +
    (Task Completion Rate × 0.25) +
    (Eval Score × 10 × 0.30) +
    (Avg Skill Level × 10 × 0.20)
```

## 🤖 AI Suggestions Engine

The `generate_suggestions()` function in `analytics/engine.py` auto-generates
personalized suggestions based on:
- Attendance rate thresholds (< 75%, < 90%, ≥ 90%)
- Task completion rate (< 50%, ≥ 80%)
- Evaluation scores (< 6, ≥ 7)
- Skill proficiency averages
- Overall performance score

## 🎨 Design

- **Theme:** Dark mode (`#0a0f1e` base)
- **Typography:** Space Grotesk (headings) + Inter (body)
- **Primary color:** Indigo `#6366f1`
- **Charts:** Plotly with transparent backgrounds

## 🔧 Customization

- Add new skill categories in `frontend/intern_module.py`
- Adjust KPI weights in `analytics/engine.py → compute_kpis()`
- Extend suggestion rules in `analytics/engine.py → generate_suggestions()`
- Add new chart types in `analytics/charts.py`
